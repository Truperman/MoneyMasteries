-- ============================================================
--  MONEY MASTERIES — Supabase Database Schema
--  Platform: PostgreSQL via Supabase
--  Run this in the Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. USERS & SUBSCRIPTIONS
-- ============================================================

-- Extends Supabase's built-in auth.users table
CREATE TABLE public.profiles (
  id                UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name         TEXT NOT NULL,
  email             TEXT NOT NULL UNIQUE,
  avatar_url        TEXT,
  plan              TEXT NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'pro')),
  revenuecat_id     TEXT UNIQUE,                        -- RevenueCat customer ID
  referral_code     TEXT UNIQUE NOT NULL,               -- e.g. "ken123" — auto-generated
  referred_by       UUID REFERENCES public.profiles(id), -- who recruited this user
  is_lifetime_free  BOOLEAN DEFAULT FALSE,              -- true = joined during 90-day window
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Subscription history (synced from RevenueCat webhooks)
CREATE TABLE public.subscriptions (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id           UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  plan              TEXT NOT NULL CHECK (plan IN ('free', 'pro')),
  status            TEXT NOT NULL CHECK (status IN ('active', 'cancelled', 'expired', 'trial')),
  revenuecat_sub_id TEXT,
  started_at        TIMESTAMPTZ DEFAULT NOW(),
  expires_at        TIMESTAMPTZ,
  cancelled_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Global settings (e.g. 90-day free window)
CREATE TABLE public.settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
INSERT INTO public.settings (key, value) VALUES
  ('free_window_start', NOW()::TEXT),
  ('free_window_days',  '90'),
  ('affiliate_free_commission',    '5.00'),
  ('affiliate_pro_commission',     '25.00'),
  ('affiliate_product_commission', '0.10');  -- 10%


-- ============================================================
-- 2. EDUCATION — PATHS, COURSES, CHAPTERS
-- ============================================================

-- Learning paths (Day Trading, E-Commerce, Real Estate)
CREATE TABLE public.learning_paths (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug        TEXT UNIQUE NOT NULL,          -- e.g. 'day-trading'
  title       TEXT NOT NULL,
  description TEXT,
  icon        TEXT,                          -- emoji or image URL
  sort_order  INT DEFAULT 0,
  is_active   BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO public.learning_paths (slug, title, description, icon, sort_order) VALUES
  ('day-trading',   'Day Trading Mastery',      'Master technical analysis, risk management, and live trading.',  '📈', 1),
  ('ecommerce',     'E-Commerce Blueprint',      'Build a profitable online store from product research to first sale.', '🛍️', 2),
  ('real-estate',   'Real Estate Investing',     'Analyze deals, find financing, and build passive income through property.', '🏠', 3);

-- Chapters within each path (gated — must complete in order)
CREATE TABLE public.chapters (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  path_id       UUID NOT NULL REFERENCES public.learning_paths(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  content       TEXT,                        -- rich text / markdown body
  video_url     TEXT,
  duration_mins INT DEFAULT 20,
  sort_order    INT NOT NULL,
  is_published  BOOLEAN DEFAULT TRUE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Each chapter has exactly one action task to unlock the next
CREATE TABLE public.chapter_tasks (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  chapter_id   UUID NOT NULL REFERENCES public.chapters(id) ON DELETE CASCADE,
  title        TEXT NOT NULL,
  description  TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- User progress: which chapters they've completed
CREATE TABLE public.user_progress (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  chapter_id   UUID NOT NULL REFERENCES public.chapters(id) ON DELETE CASCADE,
  task_id      UUID REFERENCES public.chapter_tasks(id),
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (user_id, chapter_id)
);

-- User's chosen learning path
CREATE TABLE public.user_paths (
  user_id    UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  path_id    UUID NOT NULL REFERENCES public.learning_paths(id) ON DELETE CASCADE,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (user_id, path_id)
);


-- ============================================================
-- 3. MARKETPLACE — DIGITAL PRODUCTS
-- ============================================================

CREATE TABLE public.products (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  seller_id     UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title         TEXT NOT NULL,
  description   TEXT,
  category      TEXT CHECK (category IN ('day-trading', 'ecommerce', 'real-estate', 'template', 'mini-course', 'other')),
  price         NUMERIC(10,2) NOT NULL CHECK (price >= 0),
  file_url      TEXT,                         -- secure signed URL to downloadable file
  thumbnail_url TEXT,
  status        TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  total_sales   INT DEFAULT 0,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Product purchases
CREATE TABLE public.product_purchases (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id    UUID NOT NULL REFERENCES public.products(id),
  buyer_id      UUID NOT NULL REFERENCES public.profiles(id),
  referred_by   UUID REFERENCES public.profiles(id),   -- affiliate who gets commission
  amount_paid   NUMERIC(10,2) NOT NULL,
  stripe_payment_id TEXT,
  purchased_at  TIMESTAMPTZ DEFAULT NOW()
);


-- ============================================================
-- 4. AFFILIATE & COMMISSIONS
-- ============================================================

-- All referral events (click → signup → purchase chain)
CREATE TABLE public.affiliate_clicks (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referral_code TEXT NOT NULL,               -- the ref code used
  referrer_id   UUID REFERENCES public.profiles(id),
  dest          TEXT DEFAULT 'signup',       -- 'signup' | 'pro' | 'market'
  ip_hash       TEXT,                        -- hashed for deduplication
  clicked_at    TIMESTAMPTZ DEFAULT NOW()
);

-- Commission ledger — one row per earning event
CREATE TABLE public.commissions (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  earner_id     UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  referred_user UUID REFERENCES public.profiles(id),
  event_type    TEXT NOT NULL CHECK (event_type IN ('free_signup', 'pro_signup', 'product_sale')),
  product_id    UUID REFERENCES public.products(id),
  purchase_id   UUID REFERENCES public.product_purchases(id),
  amount        NUMERIC(10,2) NOT NULL,
  status        TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'cancelled')),
  payout_id     UUID,                        -- references payouts table when paid
  earned_at     TIMESTAMPTZ DEFAULT NOW(),
  paid_at       TIMESTAMPTZ
);

-- Payout batches (e.g. monthly payouts via Stripe)
CREATE TABLE public.payouts (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID NOT NULL REFERENCES public.profiles(id),
  total_amount NUMERIC(10,2) NOT NULL,
  stripe_payout_id TEXT,
  status       TEXT DEFAULT 'processing' CHECK (status IN ('processing', 'sent', 'failed')),
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  sent_at      TIMESTAMPTZ
);


-- ============================================================
-- 5. PRO TOOLS USAGE LOGS (optional analytics)
-- ============================================================

CREATE TABLE public.tool_usage (
  id        UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id   UUID NOT NULL REFERENCES public.profiles(id),
  tool_slug TEXT NOT NULL,   -- 'trading-scanner' | 'deal-analyzer' | 'product-finder' | etc.
  used_at   TIMESTAMPTZ DEFAULT NOW()
);


-- ============================================================
-- 6. HELPFUL VIEWS
-- ============================================================

-- Affiliate earnings summary per user
CREATE OR REPLACE VIEW public.affiliate_summary AS
SELECT
  earner_id,
  SUM(amount) FILTER (WHERE status IN ('pending','paid'))   AS total_earned,
  SUM(amount) FILTER (WHERE status = 'pending')              AS pending_payout,
  SUM(amount) FILTER (WHERE status = 'paid')                 AS total_paid,
  COUNT(*) FILTER (WHERE event_type = 'free_signup')         AS free_signups,
  COUNT(*) FILTER (WHERE event_type = 'pro_signup')          AS pro_signups,
  COUNT(*) FILTER (WHERE event_type = 'product_sale')        AS product_sales
FROM public.commissions
GROUP BY earner_id;

-- User progress summary per path
CREATE OR REPLACE VIEW public.path_progress AS
SELECT
  up.user_id,
  c.path_id,
  lp.title AS path_title,
  COUNT(c.id)                                       AS total_chapters,
  COUNT(uprog.chapter_id)                           AS completed_chapters,
  ROUND(COUNT(uprog.chapter_id)::NUMERIC / NULLIF(COUNT(c.id),0) * 100, 1) AS pct_complete
FROM public.chapters c
JOIN public.learning_paths lp ON lp.id = c.path_id
CROSS JOIN public.profiles up
LEFT JOIN public.user_progress uprog
  ON uprog.chapter_id = c.id AND uprog.user_id = up.id
GROUP BY up.user_id, c.path_id, lp.title;


-- ============================================================
-- 7. ROW-LEVEL SECURITY (RLS)
-- ============================================================

ALTER TABLE public.profiles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_progress     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_paths        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.commissions       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.affiliate_clicks  ENABLE ROW LEVEL SECURITY;

-- Users can only read/update their own profile
CREATE POLICY "Own profile" ON public.profiles
  FOR ALL USING (auth.uid() = id);

-- Users can only see their own progress
CREATE POLICY "Own progress" ON public.user_progress
  FOR ALL USING (auth.uid() = user_id);

-- Users can only see their own commissions
CREATE POLICY "Own commissions" ON public.commissions
  FOR SELECT USING (auth.uid() = earner_id);

-- Users can see their own purchases
CREATE POLICY "Own purchases" ON public.product_purchases
  FOR SELECT USING (auth.uid() = buyer_id);

-- Products are public (approved only)
CREATE POLICY "Public products" ON public.products
  FOR SELECT USING (status = 'approved');

-- Sellers can manage their own products
CREATE POLICY "Own products" ON public.products
  FOR ALL USING (auth.uid() = seller_id);

-- Chapters and paths are publicly readable
CREATE POLICY "Public chapters"      ON public.chapters       FOR SELECT USING (is_published = TRUE);
CREATE POLICY "Public paths"         ON public.learning_paths FOR SELECT USING (is_active = TRUE);

-- ============================================================
-- 8. AUTOMATIC REFERRAL CODE GENERATION
-- ============================================================

CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS TRIGGER AS $$
DECLARE
  code TEXT;
  exists BOOLEAN;
BEGIN
  LOOP
    -- Generate a short alphanumeric code
    code := lower(substring(md5(NEW.id::TEXT || NOW()::TEXT) FROM 1 FOR 8));
    SELECT EXISTS (SELECT 1 FROM public.profiles WHERE referral_code = code) INTO exists;
    EXIT WHEN NOT exists;
  END LOOP;
  NEW.referral_code := code;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER set_referral_code
  BEFORE INSERT ON public.profiles
  FOR EACH ROW
  WHEN (NEW.referral_code IS NULL OR NEW.referral_code = '')
  EXECUTE FUNCTION generate_referral_code();

-- ============================================================
-- END OF SCHEMA
-- ============================================================
