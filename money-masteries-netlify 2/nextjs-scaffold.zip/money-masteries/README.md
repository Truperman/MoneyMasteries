# Money Masteries — Developer Guide

## Tech Stack
- **Next.js 14** (App Router) — web frontend & API routes
- **Supabase** — database (PostgreSQL), auth, row-level security
- **RevenueCat** — subscription billing (Free + Pro tiers)
- **Stripe** — digital product payments & affiliate payouts
- **Tailwind CSS** — styling

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
cp .env.local.example .env.local
# Fill in your Supabase, RevenueCat, and Stripe keys

# 3. Set up the database
# Copy the contents of money-masteries-schema.sql into
# Supabase Dashboard → SQL Editor → Run

# 4. Run dev server
npm run dev
```

## Project Structure

```
src/
├── app/
│   ├── layout.tsx              # Root layout
│   ├── dashboard/page.tsx      # Member dashboard
│   ├── courses/page.tsx        # Learning paths
│   ├── marketplace/page.tsx    # Digital products
│   ├── affiliate/page.tsx      # Affiliate links
│   ├── commissions/page.tsx    # Commission history
│   ├── tools/page.tsx          # Pro member tools
│   └── api/
│       ├── webhooks/revenuecat/ # RevenueCat subscription events
│       ├── webhooks/stripe/     # Stripe payment events
│       ├── affiliate/click/     # Record affiliate clicks
│       ├── products/            # Product CRUD
│       └── commissions/         # Commission queries
├── components/
│   ├── ui/                     # Buttons, cards, badges
│   ├── layout/                 # Sidebar, navbar
│   ├── courses/                # Chapter viewer, progress
│   ├── affiliate/              # Link generator, stats
│   ├── marketplace/            # Product grid, sell form
│   └── tools/                  # Pro tool cards
├── lib/
│   ├── supabase.ts             # Supabase client
│   ├── revenuecat.ts           # RevenueCat helpers
│   └── affiliate.ts            # Link utilities
├── hooks/                      # Custom React hooks
└── types/index.ts              # TypeScript types

## Key Flows

### Affiliate Flow
1. Member shares link: `moneymasteries.com/ref/ken123`
2. Visitor clicks → `/ref/[code]` page records the click (API route)
3. Referral code stored in sessionStorage
4. Visitor signs up → referral code attached to their profile
5. RevenueCat webhook fires on Pro upgrade → commission created
6. Monthly cron job pays out pending commissions via Stripe

### Course Gating Flow
1. User picks a learning path
2. Chapter 1 is unlocked by default
3. User reads chapter, completes action task → marks done
4. `user_progress` row inserted → next chapter unlocks
5. Progress tracked via `path_progress` view

### Subscription Flow
1. User clicks "Go Pro"
2. RevenueCat Web SDK opens purchase flow
3. On success → RC fires webhook to `/api/webhooks/revenuecat`
4. Webhook updates `profiles.plan = 'pro'` in Supabase
5. App checks plan on next auth → Pro features unlock
```

## Deploying

Recommended: **Vercel** (zero-config for Next.js)
1. Push to GitHub
2. Connect repo to Vercel
3. Add all `.env.local` variables to Vercel's environment settings
4. Deploy — done ✅
