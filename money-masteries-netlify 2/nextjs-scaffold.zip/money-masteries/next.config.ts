import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  images: {
    domains: ['your-project.supabase.co'],  // replace with your Supabase project URL
  },
};

export default nextConfig;
