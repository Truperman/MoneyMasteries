// ============================================================
//  Record an affiliate link click
//  Called by the /ref/[code] redirect page
// ============================================================
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { createHash } from 'crypto';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(req: NextRequest) {
  const { referral_code, dest = 'signup' } = await req.json();

  if (!referral_code) {
    return NextResponse.json({ error: 'Missing referral_code' }, { status: 400 });
  }

  // Look up the referrer
  const { data: referrer } = await supabase
    .from('profiles')
    .select('id')
    .eq('referral_code', referral_code)
    .single();

  // Hash IP for deduplication (privacy-friendly)
  const ip = req.headers.get('x-forwarded-for') ?? req.headers.get('x-real-ip') ?? '';
  const ip_hash = createHash('sha256').update(ip).digest('hex').slice(0, 16);

  await supabase.from('affiliate_clicks').insert({
    referral_code,
    referrer_id: referrer?.id ?? null,
    dest,
    ip_hash,
  });

  return NextResponse.json({ ok: true });
}
