// ============================================================
//  RevenueCat Webhook Handler
//  Receives subscription events and keeps Supabase in sync.
//  Set this URL in RevenueCat Dashboard → Integrations → Webhooks
// ============================================================
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

// Use the service-role key here (server only, never expose to client)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const RC_WEBHOOK_SECRET = process.env.REVENUECAT_WEBHOOK_SECRET!;

export async function POST(req: NextRequest) {
  // 1. Verify the webhook secret
  const secret = req.headers.get('x-revenuecat-webhook-secret');
  if (secret !== RC_WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await req.json();
  const { event } = body;
  const rcUserId   = event?.app_user_id;       // RevenueCat user ID (= Supabase user ID)
  const eventType  = event?.type;

  if (!rcUserId || !eventType) {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
  }

  // 2. Handle event types
  switch (eventType) {
    case 'INITIAL_PURCHASE':
    case 'RENEWAL':
      // User subscribed / renewed → set plan to 'pro'
      await supabase.from('profiles')
        .update({ plan: 'pro', updated_at: new Date().toISOString() })
        .eq('id', rcUserId);

      await supabase.from('subscriptions').upsert({
        user_id:          rcUserId,
        plan:             'pro',
        status:           'active',
        revenuecat_sub_id: event.id,
        started_at:       new Date(event.purchased_at_ms).toISOString(),
        expires_at:       new Date(event.expiration_at_ms).toISOString(),
      }, { onConflict: 'revenuecat_sub_id' });

      // Credit affiliate commission if user was referred
      await creditAffiliateCommission(rcUserId, 'pro_signup');
      break;

    case 'CANCELLATION':
    case 'EXPIRATION':
      // Downgrade to free
      await supabase.from('profiles')
        .update({ plan: 'free', updated_at: new Date().toISOString() })
        .eq('id', rcUserId);
      break;

    default:
      // Acknowledge but don't process
      break;
  }

  return NextResponse.json({ received: true });
}

/** Look up the referrer and create a commission row */
async function creditAffiliateCommission(userId: string, eventType: 'free_signup' | 'pro_signup') {
  const { data: profile } = await supabase
    .from('profiles')
    .select('referred_by')
    .eq('id', userId)
    .single();

  if (!profile?.referred_by) return;

  const { data: settings } = await supabase
    .from('settings')
    .select('key, value')
    .in('key', ['affiliate_free_commission', 'affiliate_pro_commission']);

  const settingsMap = Object.fromEntries(settings?.map((s: any) => [s.key, s.value]) ?? []);
  const amount = eventType === 'pro_signup'
    ? parseFloat(settingsMap.affiliate_pro_commission  ?? '25')
    : parseFloat(settingsMap.affiliate_free_commission ?? '5');

  await supabase.from('commissions').insert({
    earner_id:     profile.referred_by,
    referred_user: userId,
    event_type:    eventType,
    amount,
    status:        'pending',
  });
}
