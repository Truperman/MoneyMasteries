'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import type { LearningPath, PathProgress } from '@/types';

export default function CoursesPage() {
  const [paths,    setPaths]    = useState<LearningPath[]>([]);
  const [progress, setProgress] = useState<PathProgress[]>([]);
  const [loading,  setLoading]  = useState(true);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const [{ data: p }, { data: prog }] = await Promise.all([
        supabase.from('learning_paths').select('*').order('sort_order'),
        supabase.from('path_progress').select('*').eq('user_id', user.id),
      ]);
      setPaths(p ?? []);
      setProgress(prog ?? []);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) return <div className="p-8 text-gray-400">Loading...</div>;

  return (
    <main className="p-8 max-w-5xl">
      <h1 className="text-2xl font-extrabold mb-1">My Education</h1>
      <p className="text-gray-400 mb-8">Choose your path to financial freedom</p>

      <div className="grid grid-cols-3 gap-5">
        {paths.map((path) => {
          const prog = progress.find((p) => p.path_id === path.id);
          const pct  = prog?.pct_complete ?? 0;
          const done = prog?.completed_chapters ?? 0;
          const total = prog?.total_chapters ?? 0;

          return (
            <Link key={path.id} href={`/courses/${path.slug}`}
              className="bg-gray-900 border border-gray-700 rounded-2xl overflow-hidden hover:border-yellow-400 transition-all hover:-translate-y-1 cursor-pointer block">
              <div className="h-28 flex items-center justify-center text-5xl bg-gradient-to-br from-gray-800 to-gray-900">
                {path.icon}
              </div>
              <div className="p-5">
                <h3 className="font-bold mb-1">{path.title}</h3>
                <p className="text-xs text-gray-400 mb-3 leading-relaxed">{path.description}</p>
                <div className="bg-gray-700 rounded-full h-1.5 mb-2">
                  <div className="bg-yellow-400 h-1.5 rounded-full" style={{ width: `${pct}%` }} />
                </div>
                <p className="text-xs text-gray-400">{done} / {total} chapters · {pct}%</p>
              </div>
            </Link>
          );
        })}
      </div>
    </main>
  );
}
