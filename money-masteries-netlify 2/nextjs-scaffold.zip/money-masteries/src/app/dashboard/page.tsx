'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { buildAffiliateLink } from '@/lib/affiliate';
import type { Profile, AffiliateSummary, Commission } from '@/types';

export default function DashboardPage() {
  const [profile,    setProfile]    = useState<Profile | null>(null);
  const [summary,    setSummary]    = useState<AffiliateSummary | null>(null);
  const [recentComm, setRecentComm] = useState<Commission[]>([]);
  const [loading,    setLoading]    = useState(true);

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const [{ data: prof }, { data: summ }, { data: comm }] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).single(),
        supabase.from('affiliate_summary').select('*').eq('earner_id', user.id).single(),
        supabase
          .from('commissions')
          .select('*, referred_user_profile:profiles!referred_user(full_name), product:products(title)')
          .eq('earner_id', user.id)
          .order('earned_at', { ascending: false })
          .limit(5),
      ]);

      setProfile(prof);
      setSummary(summ);
      setRecentComm(comm ?? []);
      setLoading(false);
    }
    load();
  }, []);

  if (loading) return <div className="p-8 text-gray-400">Loading...</div>;
  if (!profile) return null;

  const affiliateLink = buildAffiliateLink(profile.referral_code);

  return (
    <main className="p-8 max-w-6xl">
      <h1 className="text-2xl font-extrabold mb-1">Good morning, {profile.full_name.split(' ')[0]} 👋</h1>
      <p className="text-gray-400 mb-8">Here's your Money Masteries overview</p>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        <StatCard label="Total Commissions" value={`$${(summary?.total_earned ?? 0).toFixed(2)}`} color="text-emerald-400" />
        <StatCard label="Referrals" value={String((summary?.free_signups ?? 0) + (summary?.pro_signups ?? 0))} color="text-yellow-400" />
        <StatCard label="Pending Payout" value={`$${(summary?.pending_payout ?? 0).toFixed(2)}`} color="text-yellow-400" />
        <StatCard label="Your Plan" value={profile.plan.toUpperCase()} color={profile.plan === 'pro' ? 'text-yellow-400' : 'text-gray-300'} />
      </div>

      {/* Affiliate link */}
      <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6 mb-6">
        <h2 className="font-bold mb-4">Your Affiliate Link</h2>
        <div className="flex items-center gap-3 bg-gray-800 rounded-xl p-4">
          <span className="text-gray-400 text-sm flex-1 break-all">{affiliateLink}</span>
          <button
            onClick={() => navigator.clipboard.writeText(affiliateLink)}
            className="bg-yellow-400 text-gray-900 font-bold text-sm px-4 py-2 rounded-lg whitespace-nowrap hover:bg-yellow-300"
          >
            📋 Copy
          </button>
        </div>
        <p className="text-xs text-gray-500 mt-3">
          Earn <strong className="text-yellow-400">$5</strong> per free signup ·{' '}
          <strong className="text-yellow-400">$25</strong> per Pro signup ·{' '}
          <strong className="text-yellow-400">10%</strong> on product sales
        </p>
      </div>

      {/* Recent commissions */}
      <div className="bg-gray-900 border border-gray-700 rounded-2xl p-6">
        <h2 className="font-bold mb-4">Recent Affiliate Activity</h2>
        {recentComm.length === 0 ? (
          <p className="text-gray-500 text-sm">No commissions yet — share your link to start earning!</p>
        ) : (
          <div className="divide-y divide-gray-800">
            {recentComm.map((c) => (
              <div key={c.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="font-semibold text-sm">{(c as any).referred_user_profile?.full_name ?? 'Unknown'}</p>
                  <p className="text-xs text-gray-400 capitalize">{c.event_type.replace('_', ' ')}</p>
                </div>
                <span className="text-emerald-400 font-bold">+${c.amount.toFixed(2)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}

function StatCard({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="bg-gray-900 border border-gray-700 rounded-2xl p-5">
      <p className="text-xs text-gray-400 uppercase tracking-wide font-semibold mb-2">{label}</p>
      <p className={`text-3xl font-extrabold ${color}`}>{value}</p>
    </div>
  );
}
