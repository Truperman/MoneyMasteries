import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Money Masteries — Learn to Make Money from Home',
  description:
    'Structured education in Day Trading, E-Commerce, and Real Estate. Join free, earn commissions as an affiliate, and build your financial future.',
  openGraph: {
    title: 'Money Masteries',
    description: 'Learn. Earn. Grow.',
    images: ['/og-image.png'],
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  );
}
