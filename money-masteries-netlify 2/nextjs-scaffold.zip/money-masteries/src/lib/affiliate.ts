// ============================================================
//  Affiliate link utilities
// ============================================================

const BASE_URL = process.env.NEXT_PUBLIC_APP_URL ?? 'https://moneymasteries.com';

export type AffiliateDestination = 'signup' | 'pro' | 'market';

/** Generate a shareable affiliate URL */
export function buildAffiliateLink(
  referralCode: string,
  dest: AffiliateDestination = 'signup'
): string {
  const url = new URL(`/ref/${referralCode}`, BASE_URL);
  if (dest !== 'signup') url.searchParams.set('dest', dest);
  return url.toString();
}

/** Parse referral code from a URL search string (call on landing) */
export function parseReferralCode(search: string): string | null {
  // Supports /ref/CODE route (handled in middleware) or ?ref=CODE query param
  const params = new URLSearchParams(search);
  return params.get('ref') ?? null;
}

/** Store referral code in sessionStorage so it survives the signup flow */
export function storeReferralCode(code: string): void {
  if (typeof window !== 'undefined') {
    sessionStorage.setItem('mm_ref', code);
  }
}

export function retrieveReferralCode(): string | null {
  if (typeof window !== 'undefined') {
    return sessionStorage.getItem('mm_ref');
  }
  return null;
}

export function clearReferralCode(): void {
  if (typeof window !== 'undefined') {
    sessionStorage.removeItem('mm_ref');
  }
}
