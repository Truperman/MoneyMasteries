// ============================================================
//  RevenueCat Web SDK helpers
//  Docs: https://www.revenuecat.com/docs/web/web-sdk
// ============================================================

// Products/entitlements configured in your RevenueCat dashboard
export const RC_ENTITLEMENTS = {
  pro: 'pro_access',        // name this in your RevenueCat dashboard
} as const;

export const RC_PACKAGES = {
  pro_monthly: '$rc_monthly',
} as const;

/**
 * Check if a user has the "pro" entitlement via RevenueCat.
 * Call this after login to verify subscription status.
 */
export async function checkProEntitlement(userId: string): Promise<boolean> {
  try {
    // purchases-js SDK (browser)
    const { Purchases } = await import('purchases-js');
    const purchases = Purchases.configure(
      process.env.NEXT_PUBLIC_REVENUECAT_API_KEY!,
      userId
    );
    const customerInfo = await purchases.getCustomerInfo();
    return RC_ENTITLEMENTS.pro in customerInfo.entitlements.active;
  } catch (err) {
    console.error('RevenueCat check failed:', err);
    return false;
  }
}

/**
 * Purchase the Pro subscription.
 * Returns true on success, false on failure/cancellation.
 */
export async function purchasePro(userId: string): Promise<boolean> {
  try {
    const { Purchases } = await import('purchases-js');
    const purchases = Purchases.configure(
      process.env.NEXT_PUBLIC_REVENUECAT_API_KEY!,
      userId
    );
    const offerings = await purchases.getOfferings();
    const proPackage = offerings.current?.availablePackages.find(
      (p) => p.identifier === RC_PACKAGES.pro_monthly
    );
    if (!proPackage) throw new Error('Pro package not found');
    await purchases.purchasePackage(proPackage);
    return true;
  } catch (err: any) {
    if (err?.userCancelled) return false;
    console.error('Purchase failed:', err);
    return false;
  }
}
