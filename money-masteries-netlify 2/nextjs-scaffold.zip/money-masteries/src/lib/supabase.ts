// ============================================================
//  Supabase client helpers (browser + server)
// ============================================================
import { createBrowserClient } from '@supabase/ssr';

const supabaseUrl  = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

/** Use this in client components */
export const supabase = createBrowserClient(supabaseUrl, supabaseAnon);
