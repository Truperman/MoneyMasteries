// ============================================================
//  MONEY MASTERIES — Core TypeScript Types
// ============================================================

export type Plan = 'free' | 'pro';
export type SubscriptionStatus = 'active' | 'cancelled' | 'expired' | 'trial';
export type CommissionStatus = 'pending' | 'paid' | 'cancelled';
export type ProductStatus = 'pending' | 'approved' | 'rejected';
export type EventType = 'free_signup' | 'pro_signup' | 'product_sale';
export type ProductCategory = 'day-trading' | 'ecommerce' | 'real-estate' | 'template' | 'mini-course' | 'other';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  avatar_url?: string;
  plan: Plan;
  revenuecat_id?: string;
  referral_code: string;
  referred_by?: string;
  is_lifetime_free: boolean;
  created_at: string;
  updated_at: string;
}

export interface Subscription {
  id: string;
  user_id: string;
  plan: Plan;
  status: SubscriptionStatus;
  revenuecat_sub_id?: string;
  started_at: string;
  expires_at?: string;
  cancelled_at?: string;
}

export interface LearningPath {
  id: string;
  slug: string;
  title: string;
  description?: string;
  icon?: string;
  sort_order: number;
  is_active: boolean;
}

export interface Chapter {
  id: string;
  path_id: string;
  title: string;
  content?: string;
  video_url?: string;
  duration_mins: number;
  sort_order: number;
  is_published: boolean;
  task?: ChapterTask;
  is_completed?: boolean;   // hydrated client-side
  is_locked?: boolean;      // hydrated client-side
}

export interface ChapterTask {
  id: string;
  chapter_id: string;
  title: string;
  description?: string;
}

export interface UserProgress {
  id: string;
  user_id: string;
  chapter_id: string;
  task_id?: string;
  completed_at: string;
}

export interface Product {
  id: string;
  seller_id: string;
  title: string;
  description?: string;
  category: ProductCategory;
  price: number;
  file_url?: string;
  thumbnail_url?: string;
  status: ProductStatus;
  total_sales: number;
  created_at: string;
  seller?: Pick<Profile, 'full_name' | 'avatar_url'>;  // joined
}

export interface Commission {
  id: string;
  earner_id: string;
  referred_user?: string;
  event_type: EventType;
  product_id?: string;
  purchase_id?: string;
  amount: number;
  status: CommissionStatus;
  earned_at: string;
  paid_at?: string;
  referred_user_profile?: Pick<Profile, 'full_name'>;  // joined
  product?: Pick<Product, 'title'>;                    // joined
}

export interface AffiliateSummary {
  earner_id: string;
  total_earned: number;
  pending_payout: number;
  total_paid: number;
  free_signups: number;
  pro_signups: number;
  product_sales: number;
}

export interface PathProgress {
  user_id: string;
  path_id: string;
  path_title: string;
  total_chapters: number;
  completed_chapters: number;
  pct_complete: number;
}
