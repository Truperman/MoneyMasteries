import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        gold:    { DEFAULT: '#F5C842', dark: '#D4A800' },
        dark:    { DEFAULT: '#0A0E1A', 2: '#111827', 3: '#1F2937', 4: '#374151' },
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', 'sans-serif'],
      },
    },
  },
  plugins: [],
};

export default config;
